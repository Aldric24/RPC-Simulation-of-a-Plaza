﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Threading;
using Microsoft.Extensions.DependencyInjection;
using NLog;
using SimpleRpc.Serialization.Hyperion;
using SimpleRpc.Transports;
using SimpleRpc.Transports.Http.Client;
using SimpleRpc.Transports.Http.Server;
using Services;

namespace Clients
{
    /// <summary>
    /// Client example.
    /// </summary>
    class Client
    {
        //// Lists of names, surnames, and client types
        //private readonly List<string> NAMES = new List<string>
        //{
        //    "John", "Peter", "Jack", "Steve", "Alice", "Bob", "Carol", "David", "Eve", "Frank",
        //    "Grace", "Helen", "Ivy", "John", "Kelly", "Liam", "Mia", "Noah", "Olivia", "Paul",
        //    "Quinn", "Riley", "Sophia", "Thomas", "Uma", "Victor", "Willa", "Xander", "Yara", "Zane"
        //};

        //private readonly List<string> SURNAMES = new List<string>
        //{
        //    "Johnson", "Peterson", "Jackson", "Steveson", "Anderson", "Brown", "Clark", "Davis",
        //    "Evans", "Fisher", "Garcia", "Hall", "Iverson", "Johnson", "Kelly", "Lopez", "Miller",
        //    "Nelson", "Olson", "Perez", "Quinn", "Roberts", "Smith", "Thomas", "Upton", "Valdez",
        //    "Williams", "Xavier", "Young", "Zimmerman"
        //};

        //private readonly List<string> cTypes = new List<string>
        //{
        //    "Eater", "Drinker"
        //};

        // Logger for this class
        private readonly Logger mLog = LogManager.GetCurrentClassLogger();

        // Configures logging subsystem
        private void ConfigureLogging()
        {
            var config = new NLog.Config.LoggingConfiguration();
            var console = new NLog.Targets.ConsoleTarget("console")
            {
                Layout = @"${date:format=HH\:mm\:ss}|${level}| ${message} ${exception}"
            };
            config.AddTarget(console);
            config.AddRuleForAllLevels(console);
            LogManager.Configuration = config;
        }

        // Main program logic
        private void Run()
        {
            // Configure logging
            ConfigureLogging();
            var rnd = new Random();

            while (true)
            {
                try
                {
                    // Set up SimpleRpc client
                    var sc = new ServiceCollection();
                    sc.AddSimpleRpcClient("plazaservice", new HttpClientTransportOptions
                    {
                        Url = "http://127.0.0.1:5000/simplerpc",
                        Serializer = "HyperionMessageSerializer"
                    });
                    sc.AddSimpleRpcHyperionSerializer();
                    sc.AddSimpleRpcProxy<IPlazaService>("plazaservice");

                    var sp = sc.BuildServiceProvider();
                    var plaza = sp.GetService<IPlazaService>();

                    while (true)
                    {
                        int t = plaza.time().time;

                        // Clients enter plaza between 18:00 and 20:00
                        if (t >= 18 && t < 20)
                        {
                            int add=rnd.Next(50);
                            int Switch = rnd.Next(0, 2);
                            if (Switch == 0)
                            {
                                mLog.Info($"{add} Eaters are entering plaza at {t}:00");

                                // Add the seller to the plaza
                                plaza.addtoplaza("Eaters", add);
                            }
                            else
                            {
                                plaza.leave(rnd.Next(30));
                                mLog.Info($"{add} Eaters are Leaving the plaza at {t}:00");
                            }

                            Thread.Sleep(250);
                        }
                        else if (t >= 21 && t <= 7)
                        {
                            // Inactive during night hours (21:00 - 07:00)
                            mLog.Info($"Eater Component is inactive because time is {t}:00");
                            Thread.Sleep(1000);
                        }
                        //else if (t == 20)
                        //{
                        //    plaza.Convert();
                        //}
                        else
                        {
                            // Eaters cannot enter plaza at other times
                            mLog.Info($"Eaters cannot enter the plaza because time is {t}:00");
                            Thread.Sleep(1000);
                        }
                    }
                }
                catch (Exception e)
                {
                    // Log exceptions and restart the main loop
                    mLog.Warn(e, "Unhandled exception caught. Will restart the main loop.");
                    Thread.Sleep(2000);
                }
            }
        }

        // Program entry point
        static void Main(string[] args)
        {
            var self = new Client();
            self.Run();
        }
    }
}
