﻿namespace Clients;

using Microsoft.Extensions.DependencyInjection;

using SimpleRpc.Serialization.Hyperion;
using SimpleRpc.Transports;
using SimpleRpc.Transports.Http.Client;

using NLog;

using Services;
using Hyperion.Internal;
using System.Net;



/// <summary>
/// Client example.
/// </summary>
class Client
{
    

    /// <summary>
    /// Logger for this class.
    /// </summary>
    Logger mLog = LogManager.GetCurrentClassLogger();

	/// <summary>
	/// Configures logging subsystem.
	/// </summary>
	private void ConfigureLogging()
	{
		var config = new NLog.Config.LoggingConfiguration();

		var console =
			new NLog.Targets.ConsoleTarget("console")
			{
				Layout = @"${date:format=HH\:mm\:ss}|${level}| ${message} ${exception}"
			};
		config.AddTarget(console);
		config.AddRuleForAllLevels(console);

		LogManager.Configuration = config;
	}

	/// <summary>
	/// Program body.
	/// </summary>
	private void Run() {
		//configure logging
		ConfigureLogging();

		//initialize random number generator
		var rnd = new Random();

		//run everythin in a loop to recover from connection errors
		while( true )
		{
			try
			{
				//connect to the server, get service client proxy
				var sc = new ServiceCollection();
				sc
					.AddSimpleRpcClient(
						"plazaservice", //must be same as on line 86
						new HttpClientTransportOptions
						{
							Url = "http://127.0.0.1:5000/simplerpc",
							Serializer = "HyperionMessageSerializer"
						}
					)
					.AddSimpleRpcHyperionSerializer();

				sc.AddSimpleRpcProxy<IPlazaService>("plazaservice"); //must be same as on line 77

				var sp = sc.BuildServiceProvider();

				var plaza = sp.GetService<IPlazaService>();
				Time time = plaza.time();
				//initialize client descriptor

				var random = new Random();


				
				//log identity data

				//Console.Title = $"I am client {client.ClientID}, Role. {client.ClientType} Name: {client.ClientNameSurname}.";var[]
				//do the client stuff
				while (true)
				{
					int t = plaza.time().time;
                    //if (t == 17 || t == 8)
                    //{
                    //    plaza.Convert();
                    //}

                    // Sellers enter plaza between 8:00 and 16:00
                    if (t >= 8 && t <=  16)
					{
                        // Create a new client
                        int add = random.Next(50);
						int Switch=random.Next(0,2);
						if (Switch==0 && t!=16)
						{
                            mLog.Info($"{add} Sellers are entering plaza at {t}:00");

                            // Add the seller to the plaza
                            plaza.addtoplaza("Seller", add);
                        }
						else
						{
							plaza.leave(random.Next(30));
                            mLog.Info($"{add} Sellers are Leaving the plaza at {t}:00");
                        }
                        // Log seller entering plaza
                        
                        Thread.Sleep(250);
                    }
					
                    else if (t >= 21 && t <= 7)
                    {
                        // Inactive during night hours (21:00 - 07:00)
						mLog.Info($"Seller Component is inactive because time is {t}:00");
						Thread.Sleep(1000);
					}
					else
					{
						// No more sellers entering the plaza at other times
						mLog.Info($"No More Sellers entering the Plaza, because time is {t}:00");
						Thread.Sleep(1000);
					}
				}
			}

			catch (Exception e)
			{
				//log whatever exception to console
				mLog.Warn(e, "Unhandled exception caught. Will restart main loop.");

				//prevent console spamming
				Thread.Sleep(2000);
			}
		}
	}

	/// <summary>
	/// Program entry point.
	/// </summary>
	/// <param name="args">Command line arguments.</param>
	static void Main(string[] args)
	{
		var self = new Client();
		self.Run();
	}
}
