using NLog.Fluent;
namespace Servers;
using NLog;
using Services;



/// <summary>
/// Traffic light state descritor.
/// </summary>
/// <summary>
/// Represents the state of the plaza including traffic light state and client queue.
/// </summary>
public class PlazaState
{
    /// <summary>
    /// Access lock to ensure thread safety.
    /// </summary>
    public readonly object AccessLock = new object();

    /// <summary>
    /// Last unique ID value generated for clients.
    /// </summary>
    public int LastUniqueId;

    /// <summary>
    /// Current plaza time state.
    /// </summary>
    public Time time = new Time();

  
}

/// <summary>
/// <para>Traffic light logic.</para>
/// <para>Thread safe.</para>
/// </summary>
/// <summary>
/// Represents the logic and state management of the plaza's traffic light and client queue.
/// </summary>
class PlazaTimeState
{
    /// <summary>
    /// Logger for this class.
    /// </summary>
    private Logger mLog = LogManager.GetCurrentClassLogger();

    

    /// <summary>
    /// Background task thread for plaza operations.
    /// </summary>
    private Thread mBgTaskThread;


    public PlazaContainer plaza = new PlazaContainer() { Seller=100 };
    /// <summary>
    /// State descriptor for the plaza.
    /// </summary>
    private PlazaState mState = new PlazaState();

    /// <summary>
    /// Constructor for PlazaTimeState.
    /// </summary>
    public PlazaTimeState()
    {
        // Start the background task for plaza operations
        mBgTaskThread = new Thread(BackgroundTask);
        mBgTaskThread.Start();

        // Start the thread for random client leaving
        //clientleaving = new Thread(RandomLeave);
        //clientleaving.Start();
    }
    

    /// <summary>
    /// Get the current plaza time state.
    /// </summary>
    /// <returns>Current time state in the plaza.</returns>
    public Services.Time time()
    {
        lock (mState.AccessLock)
        {
            return mState.time;
        }
    }

    /// <summary>
    /// Queue a client at the plaza entrance. Succeeds if the plaza is open.
    /// </summary>
    /// <param name="client">The client to add to the plaza.</param>
    /// <returns>True on success, false on failure.</returns>
    public void PlazaAccumulation(string tag,int client)
    {
        lock (mState.AccessLock)
        {
           if(tag=="Seller")
           {
                plaza.Seller += client;
                mLog.Info($" {client} Sellers have entered the plaza at {time().time}:00");
                
           }
            else
            {
                plaza.Eater += client;
                mLog.Info($" {client} Eaters have entered the plaza at {time().time}:00");
                
            }

        }
    }

    /// <summary>
    /// Convert clients based on plaza time.
    /// </summary>
    /// <param name="convert">List of clients to convert.</param>
    public void Convert()
    {
        var random = new Random();
        lock (mState.AccessLock)
        {
            if (time().time == 17)
            {
                mLog.Info($"{plaza.Seller} Remaining Sellers are now Eaters at {time().time}:00");
                plaza.Eater = plaza.Seller;
                plaza.Seller = 0;
                //Thread.Sleep(5000);
                return;
            }
            else if (time().time == 20)
            {
                mLog.Info($"{plaza.Eater} Remaining Eaters are now Drinkers at {time().time}:00");
                plaza.Drinker = plaza.Eater;
                plaza.Eater = 0;
                //Thread.Sleep(5000);
                return;
            }
            else if (time().time == 8 && plaza.Drinker!=0)
            {
                int rand= random.Next(2,50);
                int randomdriker= plaza.Drinker - rand;
                mLog.Info($"{randomdriker} Drinkers are now Sellers at {time().time}:00");
                mLog.Info($"{rand} drinkers have left the plaza at {time().time}:00");
                plaza.Seller = randomdriker;
                plaza.Drinker = 0;
                //Thread.Sleep(500);
            }
            else
                return;


        }
    }

    /// <summary>
    /// Simulate clients leaving the plaza at random times.
    /// </summary>
    public void RandomLeave(int clientamt)
    {
        var random = new Random();
        if (plaza.PlazaSize != 0)
        {
            lock (mState.AccessLock)
            {
                
                if((time().time >= 8 && time().time < 17) && clientamt < plaza.Seller)
                {
                    plaza.Seller -= clientamt;
                    plaza.PlazaSize = plaza.Seller + plaza.Eater + plaza.Drinker;
                    mLog.Info($"{clientamt} Sellers have left the plaza, and plaza size is {plaza.PlazaSize}");
                }
                else 
                {
                    plaza.Eater -= clientamt ;
                    plaza.PlazaSize = plaza.Seller + plaza.Eater + plaza.Drinker;
                    mLog.Info($"{clientamt} Eaters have left the plaza, and plaza size is {plaza.PlazaSize}");
                }
                
            }
            Thread.Sleep(250);
        }



    }

    /// <summary>
    /// Background task for simulating plaza time and updating plaza status.
    /// </summary>
    private void BackgroundTask()
    {
        var hour = 7;
        int day = 1;

        while (true)
        {
            // Update the hour
            hour = (hour + 1) % 24;
            var random = new Random();

            if (hour == 8)
            {
                mLog.Info($"Day: {day}");
                day++;
            }

            // Switch the light
            lock (mState.AccessLock)
            {
                mState.time.time = hour;
                plaza.PlazaSize = plaza.Seller + plaza.Eater + plaza.Drinker;

                if (hour >= 8 && hour <= 21 )
                {
                    int leaveno = random.Next(10);
                    string plazaStatus = "Plaza is open.";
                    string formattedTime = $"Hour: {hour}:00";
                    string plazaSizeInfo = $"Plaza size is: {plaza.PlazaSize}";
                    

                    mLog.Info($"\n{plazaStatus,-20} {formattedTime,-15} {plazaSizeInfo}\n");
                    if (hour == 17 || hour == 8)
                    {
                        Convert();

                    }
                    else if (hour == 20)
                    {
                        Convert();
                    }
                }
                else
                {
                    string plazaStatus = "Plaza is closed.";
                    string formattedTime = $"Hour: {hour}:00";
                    string plazaSizeInfo = $"Plaza size is: {plaza.PlazaSize}";

                    mLog.Info($"\n{plazaStatus,-20} {formattedTime,-15} {plazaSizeInfo}\n");
                }
            }

            Thread.Sleep(5000);
        }
    }
}