namespace Servers
{
    using Services;

    /// <summary>
    /// Represents the Plaza Service in the plaza management system.
    /// </summary>
    public class PlazaService : IPlazaService
    {
        // NOTE: In a non-singleton service, logic would need to be static or injected from a singleton instance.
        private readonly PlazaTimeState mLogic = new PlazaTimeState();

        /// <summary>
        /// Get the next unique ID from the server. Used by clients to acquire client IDs.
        /// </summary>
        /// <returns>Unique ID.</returns>
        

        /// <summary>
        /// Get the current plaza time state.
        /// </summary>
        /// <returns>Current time state in the plaza.</returns>
        public Services.Time time()
        {
            return mLogic.time();
        }

        /// <summary>
        /// Queue a client at the plaza entrance. Succeeds if the plaza is open.
        /// </summary>
        /// <param name="client">The client to add to the plaza.</param>
        /// <returns>True on success, false on failure.</returns>
        public void addtoplaza(string tag,int client)
        {
             mLogic.PlazaAccumulation(tag,client);
        }

        public void leave(int client)
        {
            mLogic.RandomLeave(client);
        }

        public void Convert()
        {
            mLogic.Convert();
        }
    }
}
