﻿using System.Runtime.InteropServices;

namespace Services
{
    /// <summary>
    /// Represents a client descriptor in the plaza management system.
    /// </summary>
    public class ClientDesc
    {
        /// <summary>
        /// Gets or sets the unique ID of the client.
        /// </summary>
        public int Generated_Amt = 0;

        /// <summary>
        /// Gets or sets the type of the client (e.g., "Seller", "Eater").
        /// </summary>
        public string ClientType = "Seller";

        /// <summary>
        /// Gets or sets the name and surname of the client.
        /// </summary>
        public string ClientNameSurname { get; set; }
    }
    public class PlazaContainer
    {
        public int Seller = 0;
        public int Eater = 0;
        public int Drinker = 0;
        public int PlazaSize = 0;
    }
    /// <summary>
    /// Represents the current time in the plaza management system.
    /// </summary>
    public class Time
    {
        public int time = 0;
    }

    /// <summary>
    /// Service contract interface for the plaza management system.
    /// </summary>
    public interface IPlazaService
    {
        /// <summary>
        /// Adds a client to the plaza.
        /// </summary>
        /// <param name="client">The client to add to the plaza.</param>
        /// <returns>True on success, false on failure.</returns>
        void addtoplaza(string tag,int client);
        void leave(int client);
        void Convert();

        /// <summary>
        /// Gets the current time in the plaza.
        /// </summary>
        /// <returns>The current time.</returns>
        Time time();
    }
}
